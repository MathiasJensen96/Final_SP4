import java.util.ArrayList;

public class Menu {

    ArrayList<Pizza> menuCard = new ArrayList<Pizza>();
    ArrayList<Order> orderlist = new ArrayList<Order>();
    MarioJDBC marioJDBC = new MarioJDBC();

    public void Order() {
        populateMenuCard();
    }

    public Menu() {
        populateMenuCard();
    }

    public ArrayList<Pizza> getMenu() {
        return menuCard;
    }

    public void showMenu() {
        for (Pizza p : menuCard) {
            System.out.println(p);
        }
    }

    private void populateMenuCard() {
        menuCard = marioJDBC.getMenuFromDB();
    }
}
