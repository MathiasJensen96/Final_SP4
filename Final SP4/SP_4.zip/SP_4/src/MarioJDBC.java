import java.sql.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MarioJDBC {

    private Connection conn;
    String JdbcUrl = "jdbc:mysql://localhost/MariosPizza?" + "autoReconnect=true&useSSL=false";
    String username = "root";
    String password = "Cervelo2011";

    public MarioJDBC() {
        createConnection();
    }

    public void createConnection() {
        try {
            conn = DriverManager.getConnection(JdbcUrl, username, password);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public ArrayList<Order> getOrdersFromDB() {
        ArrayList<Order> tmp = new ArrayList<>();
        try {

            PreparedStatement pstm;
            String sql = "select * from MariosPizza.order";
            pstm = conn.prepareStatement(sql);
            ResultSet resultSet;

            resultSet = pstm.executeQuery(sql);

            Order order = new Order();
            while (resultSet.next())
            {
                int orderID = resultSet.getInt("OrderID");

                if (order.orderID == orderID) // SAME ORDER
                {
                    order.pizzas.add(getPizzaFromDatabase(resultSet.getInt("pizzaID")));
                }
                else
                {

                    order = new Order();
                    order.orderID = orderID;
                    order.deliveryTime = resultSet.getDate("deliveryTime");
                    order.pizzas.add((getPizzaFromDatabase(resultSet.getInt("pizzaID"))));

                    tmp.add(order);
                }
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        System.out.println(tmp);
        return tmp;
    }

    public ArrayList<Pizza> getMenuFromDB() {
        // TODO: have a look at preparedStatements!
        ArrayList<Pizza> tmp = new ArrayList<Pizza>();

        try {
            if(!conn.isValid(1))
            {
                System.out.println("No connection found");
                createConnection();
            }

            Statement stm;
            stm = conn.createStatement();
            String sql = "select * from MariosPizza.Pizza";
            ResultSet resultSet;
            resultSet = stm.executeQuery(sql);

            while (resultSet.next()) {
                Pizza pizza = new Pizza(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("Topping"),
                        resultSet.getInt("Price")
                );
                tmp.add(pizza);
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return tmp;
    }

    public void saveOrderToDatabase(Order o)
    {
        String sql = "INSERT INTO MariosPizza.order (OrderID, deliveryTime, pizzaID) VALUES (?,?,?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);

            java.util.Date utilDate = new java.util.Date(System.currentTimeMillis()+ TimeUnit.MINUTES.toMillis(o.time));
            java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

            for (Pizza p : o.pizzas)
            {
                ps.setInt(1, o.orderID);
                ps.setDate(2, sqlDate);
                ps.setInt(3,p.getId());

                ps.execute();
                // TODO: Increment static orderID
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void removeFromDatabase(int orderID)    {

        String sql = "DELETE FROM mariospizza.order WHERE orderID = ?";
        try {
            System.out.println(orderID);
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, orderID);
            ps.execute();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public Pizza getPizzaFromDatabase(int id)
    {
        Pizza pizza = null;
        String sql = "SELECT * FROM mariospizza.pizza WHERE id = ?";
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet resultSet = ps.executeQuery();
            while (resultSet.next()) {

                int pizzaID = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String topping = resultSet.getString("Topping");
                int price = resultSet.getInt("Price");
                pizza = new Pizza(pizzaID, name, topping, price);
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return pizza;
    }
    public int getHighestOrderIDFromDB() {
        String sql = "SELECT OrderID FROM MariosPizza.order ORDER BY OrderID desc limit 1";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return 0;
    }
    public void updateAmountInDB(int id) {
        String sql = "UPDATE MariosPizza.Statistics Set Amount = (?) WHERE ID = (?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();

            if (resultSet.next()) {

                int amount = resultSet.getInt("amount");
                int pizzaID = resultSet.getInt("id");
                amount++;
                ps.setInt(pizzaID, amount);

                ps.execute();
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}