import java.util.Scanner;

public class Main {

    static char buyMore;
    static int orderID = 0;
    static Order order;
    static Menu menu;
    static MariosSystem mariosSystem;
    static MarioJDBC marioJDBC;
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {


        menu = new Menu();
        mariosSystem = new MariosSystem();
        marioJDBC = new MarioJDBC();
        options();
    }

    public static void options() {
        System.out.println(mariosSystem.step1.get(0));
        System.out.println(mariosSystem.step1.get(1));
        System.out.println(mariosSystem.step1.get(3));
        System.out.println(mariosSystem.step1.get(4));
        boolean finished = false;
        while (!finished){
            String choice = input.nextLine();
            switch (choice){
                case"1":
                    menu.showMenu();
                    options();
                    break;
                case"2":
                    order = new Order();
                    order.setOrderID(marioJDBC.getHighestOrderIDFromDB()+1);
                    menu.showMenu();
                    System.out.println(mariosSystem.step1.get(2));
                    order.selectPizza();
                    break;
                case "3":
                    marioJDBC.getOrdersFromDB();
                    options();
                    break;
                case "4":
                    mariosSystem.removeOrderFromDB(input);
                    options();
            }
        }
    }
}